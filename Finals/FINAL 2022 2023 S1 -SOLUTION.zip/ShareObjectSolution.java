import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SharedObjectExam {
    public StringBuilder sharedString;

    private Lock lock = new ReentrantLock();
    private Condition T1Finished = lock.newCondition();
    private Condition T2Finished = lock.newCondition();
    private Condition T3Finished = lock.newCondition();
    private Condition END = lock.newCondition();

    private boolean isT1Finished = false;
    private boolean isT2Finished = false;
    private boolean isT3Finished = false;
    private boolean isEnd = false;

    public SharedObjectExam() {
        sharedString = new StringBuilder();
    }

    public void appendString(String text) {
        sharedString.append(text);
    }

    class Task1 implements Runnable {
        public void run() {
            lock.lock();
            try {
                appendString("T1");
                System.out.println("END OF T1");

                isT1Finished = true;
                T1Finished.signal();
            } finally {
                lock.unlock();
            }
        }
    }

    class Task2 implements Runnable {
        public void run() {
            lock.lock();
            try {
                while(!isT1Finished) T1Finished.await();

                appendString("T2");
                System.out.println("END OF T2");
                
                isT2Finished = true;
                T2Finished.signalAll();
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
                System.exit(1);
            } finally {
                lock.unlock();
            }
        }
    }

    class Task3 implements Runnable {
        public void run() {
            lock.lock();
            try {
                while(!isT2Finished) T2Finished.await();
                if(isEnd) return;

                appendString("T3");
                System.out.println("END OF T3");

                isT3Finished = true;
                T3Finished.signal();
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
                System.exit(1);
            } finally {
                lock.unlock();
            }
        }
    }

    class Task4 implements Runnable {
        public void run() {
            lock.lock();
            try {
                while(!isT3Finished) T3Finished.await();

                appendString("T4");
                System.out.println("END OF T4");

                isEnd = true;
                END.signal();
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
                System.exit(1);
            } finally {
                lock.unlock();
            }
        }
    }

    class Task5 implements Runnable {
        public void run() {
            lock.lock();
            try {
                while(!isT2Finished) T2Finished.await();
                if(isT3Finished) return;

                appendString("T5");
                System.out.println("END OF T5");

                isEnd = true;
                END.signal();
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
                System.exit(1);
            } finally {
                lock.unlock();
            }
        }
    }

    class EndTask implements Runnable {
        public void run() {
            lock.lock();
            try {
                while(!isEnd) END.await();
                appendString("END");
                System.out.println("THE END");
                System.out.println(sharedString.toString());
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
                System.exit(1);
            } finally {
                lock.unlock();
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        SharedObjectExam sharedObject = new SharedObjectExam();

        Thread t1 = new Thread(sharedObject.new Task1());
        Thread t2 = new Thread(sharedObject.new Task2());
        Thread t3 = new Thread(sharedObject.new Task3());
        Thread t4 = new Thread(sharedObject.new Task4());
        Thread t5 = new Thread(sharedObject.new Task5());
        Thread endThread = new Thread(sharedObject.new EndTask());

        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        endThread.start();
        if (endThread.isAlive())
            endThread.join();
        System.out.println("END OF MAIN as endThread is Alive : " + endThread.isAlive());

    }
}
