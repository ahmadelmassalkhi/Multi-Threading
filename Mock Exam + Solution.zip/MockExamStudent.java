import java.util.Random;

public class MockExamStudent {

    public static int GlobalX = 0;

    public static void main(String[] args) {
        Thread T1 = new Thread(new T1());
        Thread T2 = new Thread(new T2());
        T1.start();
        T2.start();
    }

    private static class T1 implements Runnable {

        int localX;

        @Override
        public void run() {
            int count = 1;
            while (count < 5) {
                
                //T1's turn for generating random new random value
                Random random = new Random();
                localX = random.nextInt(10) + 1; // Generate a value between 1 and 10
                System.out.println("--NEW--Generated local value at T1 : " + localX);
                //Copy the generated value to GlobalX
                GlobalX = localX;
                System.out.println("Local variable copied to global variable by T1.");
                System.out.println("Swapping the variables at T1.");
                //Swap the value of localX with GlobalX;
                int tmp = GlobalX;
                GlobalX = localX;
                localX = tmp;
                System.out.println("The new local value after swapping : " + localX + "at T1");
                count++;
            }
        }
    }

    private static class T2 implements Runnable {

        int localX;

        @Override
        public void run() {
            int count = 1;
            while (count < 5) { 
                //T2's turn for generating random new random value
                Random random = new Random();
                localX = random.nextInt(10) + 1; // Generate a value between 1 and 10
                System.out.println("Generated local value at T2: " + localX);
                System.out.println("Swapping the variables at T2.");
                //Swap the value of localX with GlobalX;
                int tmp = GlobalX;
                GlobalX = localX;
                localX = tmp;
                System.out.println("The new local value after swapping : " + localX + " at T2");
                count++;
            }
        }
    }

}
