import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class MockExamStudent_Solution {

    public static int GlobalX = 0;

    public static void main(String[] args) {
        Thread T1 = new Thread(new T1());
        Thread T2 = new Thread(new T2());
        T1.start();
        T2.start();
    }

    private static Lock lock = new ReentrantLock();
    private static Condition t1_turn = lock.newCondition();
    private static Condition t2_turn = lock.newCondition();
    private static boolean isT1Turn = true;

    private static class T1 implements Runnable {

        int localX;

        @Override
        public void run() {
            int count = 1;
            while (count < 5) {

                lock.lock();
                try {
                    while (!isT1Turn) t1_turn.await();

                    // T1's turn for generating random new random value
                    Random random = new Random();
                    localX = random.nextInt(10) + 1; // Generate a value between 1 and 10
                    System.out.println("--NEW--Generated local value at T1 : " + localX);

                    // Copy the generated value to GlobalX
                    GlobalX = localX;
                    System.out.println("Local variable copied to global variable by T1.");
                    System.out.println("Swapping the variables at T1.");

                    // Swap the value of localX with GlobalX;
                    int tmp = GlobalX;
                    GlobalX = localX;
                    localX = tmp;
                    System.out.println("The new local value after swapping : " + localX + "at T1");

                    t2_turn.signal();
                } catch (Exception e) {
                    System.err.println(e.getMessage());
                    System.exit(1);
                } finally {
                    lock.unlock();
                }
                count++;
            }
        }
    }

    private static class T2 implements Runnable {

        int localX;

        @Override
        public void run() {
            int count = 1;
            while (count < 5) {

                lock.lock();
                try {
                    while (isT1Turn) t2_turn.await();

                    // T2's turn for generating random new random value
                    Random random = new Random();
                    localX = random.nextInt(10) + 1; // Generate a value between 1 and 10
                    System.out.println("Generated local value at T2: " + localX);
                    System.out.println("Swapping the variables at T2.");

                    // Swap the value of localX with GlobalX;
                    int tmp = GlobalX;
                    GlobalX = localX;
                    localX = tmp;
                    System.out.println("The new local value after swapping : " + localX + " at T2");

                    t1_turn.signal();
                    isT1Turn = true;
                } catch (Exception e) {
                    System.err.println(e.getMessage());
                    System.exit(1);
                } finally {
                    lock.unlock();
                }
                count++;
            }
        }
    }
}
