package CountingTwoWords.Question;
import java.io.File;
import java.io.FileNotFoundException;


public class CountingTwoWords {
    public static void main(String[] args) throws FileNotFoundException, InterruptedException {
        File f1 = new File("alice-chap1-6.txt");
        File f2 = new File("alice-chap7-12.txt");

        // fill in the code to create threads to count the words in both files concurrently
    }
}
