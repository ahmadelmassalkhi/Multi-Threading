// 105344-AHMAD-MASSALKHI

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.Random;

public class FinalExam23_24_S1_Solution {

    public final int NUMBER_OF_ROUNDS = 10;
    private int BPlayerValue;
    private int WPlayerValue;
    private final Arbitre arbitre = new Arbitre();
    private final BlackPlayer blackPlayer = new BlackPlayer();
    private final WhitePlayer whitePlayer = new WhitePlayer();

    //Declare here your new variables / objects if needed
    // part 1
	private static Lock lock = new ReentrantLock();
    private static Condition isRead = lock.newCondition();
    private static Condition isGenerated = lock.newCondition();
    private static boolean black_generated = false;
    private static boolean white_generated = false;
    private static boolean wasRead = true;
    // part 2
    private static boolean terminate = false;
    private static boolean black_turn = true;
	
    class Arbitre extends Thread {

        private int BPlayerPoints = 0;
        private int WPlayerPoints = 0;

        @Override
        public void run() {
            for (int i = 0; i < NUMBER_OF_ROUNDS; i++) {
                lock.lock();
                try {
                    // wait both to generate
                    while(!(black_generated && white_generated)) {
                        isGenerated.await();
                    }

                    // read
                    if (BPlayerValue > WPlayerValue) {
                        BPlayerPoints++;
                    } else if (WPlayerValue > BPlayerValue) {
                        WPlayerPoints++;
                    }
                    System.out.println("Round " + (i + 1) + ": BPlayerValue = " + BPlayerValue + ", WPlayerValue = " + WPlayerValue);
                    System.out.println("Current Points: BPlayerPoints = " + BPlayerPoints + ", WPlayerPoints = " + WPlayerPoints);

                    // signal was read (make generators generate)
                    wasRead = true;
                    black_generated = white_generated = false;
                    isRead.signalAll();
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    System.err.println(e.getMessage());
                    System.exit(1);
                } finally {
                    lock.unlock();
                }
            }
            System.out.println("Final Points: BPlayerPoints = " + BPlayerPoints + ", WPlayerPoints = " + WPlayerPoints);
            System.out.println("End of the " + NUMBER_OF_ROUNDS + " rounds...");
            /****************************************************/

            //Part 2
            //Simulate that BPlayerPoints == WPlayerPoints
            System.out.println("Simulating that BPlayerPoints == WPlayerPoints");
            BPlayerPoints = WPlayerPoints = 2;
            if (BPlayerPoints == WPlayerPoints) {
                System.out.println("Players should now play a face-to-face gaming.");
            }
            System.out.println("---- DEATH OF ARBITRE ----");
        }
    }

    class BlackPlayer extends Thread {

        private final Random random = new Random();

        @Override
        public void run() {
            for (int i = 0; i < NUMBER_OF_ROUNDS; i++) {
                lock.lock();
                try {
                    // wait until numbers was read
                    while(black_generated || !wasRead) {
                        isRead.await();
                    }

                    // generate
                    int value = random.nextInt(10) + 1;
                    BPlayerValue = value;
                    System.out.println("BlackPlayer generated: " + value);

                    // signal if both generated
                    black_generated = true;
                    if(white_generated) {
                        isGenerated.signal();
                    }

                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    System.err.println(e.getMessage());
                    System.exit(1);
                } finally {
                    lock.unlock();
                }
            }
            /****************************************************/
            
            //Part II
            while(!terminate) {
                lock.lock();
                try {
                    // wait for white generated
                    while(!black_turn) {
                        isGenerated.await();
                    }

                    // generate
                    int value = random.nextInt(5) + 1;
                    System.out.println("BlackPlayer generated: " + value);
                    if (value == 5) {
                        System.out.println("I am BlackPlayer - I WON !!");
                        terminate = true;
                    }

                    // signal generated
                    black_turn = false;
                    isGenerated.signal();
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    System.err.println(e.getMessage());
                    System.exit(1);
                } finally {
                    lock.unlock();
                }
            }

            //End of thread.
            System.out.println(" --- DEATH OF BPLAYER ---");
        }
    }


    class WhitePlayer extends Thread {

        private final Random random = new Random();

        @Override
        public void run() {
            for (int i = 0; i < NUMBER_OF_ROUNDS; i++) {
                lock.lock();
                try {
                    // wait until values was read
                    while(white_generated || !wasRead) {
                        isRead.await();
                    }

                    // generate
                    int value = random.nextInt(5) + 1;
                    WPlayerValue = value;
                    System.out.println("WhitePlayer generated: " + value);

                    // signal if both generated
                    white_generated = true;
                    if(black_generated) {
                        isGenerated.signal();
                    }

                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    System.err.println(e.getMessage());
                    System.exit(1);
                } finally {
                    lock.unlock();
                }
            }
            /****************************************************/

            //Part II
            while(!terminate) {
                lock.lock();
                try {
                    // wait for black generated
                    while(black_turn) {
                        isGenerated.await();
                    }

                    // generate
                    int value = random.nextInt(10) + 1;
                    System.out.println("WhitePlayer generated: " + value);
                    if (value == 5) {
                        System.out.println("I am WhitePlayer - I WON !!");
                        terminate = true;
                    }

                    // signal generated
                    black_turn = true;
                    isGenerated.signal();
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    System.err.println(e.getMessage());
                    System.exit(1);
                } finally {
                    lock.unlock();
                }
            }

            //End of thread.
            System.out.println(" --- DEATH OF WPLAYER ---");
        }
    }

    public static void main(String[] args) {
        FinalExam23_24_S1_Solution exam = new FinalExam23_24_S1_Solution();
        // Start the threads
        exam.blackPlayer.start();
        exam.whitePlayer.start();
        exam.arbitre.start();
    }
}
