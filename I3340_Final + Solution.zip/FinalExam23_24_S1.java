
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.Random;

public class FinalExam23_24_S1 {

    public final int NUMBER_OF_ROUNDS = 10;
    private int BPlayerValue;
    private int WPlayerValue;
    private final Arbitre arbitre = new Arbitre();
    private final BlackPlayer blackPlayer = new BlackPlayer();
    private final WhitePlayer whitePlayer = new WhitePlayer();

    //Declare here your new variables / objects if needed
	
	
    class Arbitre extends Thread {

        private int BPlayerPoints = 0;
        private int WPlayerPoints = 0;

        @Override
        public void run() {
            for (int i = 0; i < NUMBER_OF_ROUNDS; i++) {

                if (BPlayerValue > WPlayerValue) {
                    BPlayerPoints++;
                } else if (WPlayerValue > BPlayerValue) {
                    WPlayerPoints++;
                }

            System.out.println("Round " + (i + 1) + ": BPlayerValue = " + BPlayerValue + ", WPlayerValue = " + WPlayerValue);
            System.out.println("Current Points: BPlayerPoints = " + BPlayerPoints + ", WPlayerPoints = " + WPlayerPoints);

            }
            System.out.println("Final Points: BPlayerPoints = " + BPlayerPoints + ", WPlayerPoints = " + WPlayerPoints);
            System.out.println("End of the " + NUMBER_OF_ROUNDS + " rounds...");

            //Part 2
            //Simulate that BPlayerPoints == WPlayerPoints
            System.out.println("Simulating that BPlayerPoints == WPlayerPoints");
            BPlayerPoints = WPlayerPoints = 2;
            if (BPlayerPoints == WPlayerPoints) {
                System.out.println("Players should now play a face-to-face gaming.");
            }
            System.out.println("---- DEATH OF ARBITRE ----");
        }
    }

    class BlackPlayer extends Thread {

        private final Random random = new Random();

        @Override
        public void run() {
            for (int i = 0; i < NUMBER_OF_ROUNDS; i++) {
                int value = random.nextInt(10) + 1;
                BPlayerValue = value;
                System.out.println("BlackPlayer generated: " + value);
            }
            //Part II
            int value = random.nextInt(5) + 1;
            System.out.println("BlackPlayer generated: " + value);
            if (value == 5) {
                System.out.println("I am BlackPlayer - I WON !!");
            }
            //End of thread.
            System.out.println(" --- DEATH OF BPLAYER ---");
        }
    }

    class WhitePlayer extends Thread {

        private final Random random = new Random();

        @Override
        public void run() {
            for (int i = 0; i < NUMBER_OF_ROUNDS; i++) {
                int value = random.nextInt(5) + 1;
                WPlayerValue = value;
                System.out.println("WhitePlayer generated: " + value);
            }

            //Part II
            int value = random.nextInt(10) + 1;
            System.out.println("WhitePlayer generated: " + value);
            if (value == 5) {
                System.out.println("I am WhitePlayer - I WON !!");
            }
            //End of thread.
            System.out.println(" --- DEATH OF WPLAYER ---");
        }
    }

    public static void main(String[] args) {
        FinalExam23_24_S1 exam = new FinalExam23_24_S1();
        // Start the threads
        exam.blackPlayer.start();
        exam.whitePlayer.start();
        exam.arbitre.start();
    }
}
